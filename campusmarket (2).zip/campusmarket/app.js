// CampusMarket – app.js
// ---------------------------------------------------------------
// ONE shared data source: `products` (the master list) and
// `state.filtered` (the result of the current filter).
// The catalog grid AND the gallery are both rendered from
// state.filtered, so filtering one automatically changes the other.
// ---------------------------------------------------------------

const products = [
  { id: 1, name: "Calculus Textbook", category: "Textbooks", price: 1200, image: "images/calculus.svg",
    alt: "Blue hardcover calculus textbook with an integral symbol on the cover" },
  { id: 2, name: "Intro to Databases", category: "Textbooks", price: 1500, image: "images/databases.svg",
    alt: "Green databases textbook with a stacked database cylinder icon on the cover" },
  { id: 3, name: "Organic Chemistry Notes", category: "Textbooks", price: 800, image: "images/chemistry.svg",
    alt: "Orange organic chemistry book with a hexagon molecule diagram on the cover" },
  { id: 4, name: "Scientific Calculator", category: "Electronics", price: 1800, image: "images/calculator.svg",
    alt: "Dark grey scientific calculator with a green display and a grid of keys" },
  { id: 5, name: "Desk Lamp", category: "Electronics", price: 900, image: "images/lamp.svg",
    alt: "Yellow-shaded desk lamp on a slim metal stand casting light downwards" },
  { id: 6, name: "Study Desk", category: "Furniture", price: 4500, image: "images/desk.svg",
    alt: "Wooden study desk with a single drawer on the right side" },
  { id: 7, name: "Plastic Chair", category: "Furniture", price: 700, image: "images/chair.svg",
    alt: "Blue plastic chair with a tall backrest and four straight legs" },
  { id: 8, name: "Campus Hoodie", category: "Clothing", price: 1300, image: "images/hoodie.svg",
    alt: "Red pullover hoodie with a front pocket and a hood" }
];

const MAX_QTY = 20;

const state = {
  category: "All",
  query: "",
  maxPrice: null,
  filtered: products.slice(), // what the grid AND gallery show
  slideIndex: 0,
  cart: []                    // rows: { productId, qtyRaw } (qtyRaw is the raw text typed)
};

// ---------- DOM references ----------
const searchInput = document.getElementById("search-input");
const categorySelect = document.getElementById("category-select");
const priceInput = document.getElementById("price-input");
const filterForm = document.getElementById("filter-form");
const resultCount = document.getElementById("result-count");
const productGrid = document.getElementById("product-grid");

const gallery = document.getElementById("gallery");
const galleryImage = document.getElementById("gallery-image");
const galleryCaption = document.getElementById("gallery-caption");
const galleryCounter = document.getElementById("gallery-counter");
const prevBtn = document.getElementById("prev-btn");
const nextBtn = document.getElementById("next-btn");

const cartList = document.getElementById("cart-list");
const cartEmpty = document.getElementById("cart-empty");
const cartTotal = document.getElementById("cart-total");
const cartNote = document.getElementById("cart-note");

const checkoutForm = document.getElementById("checkout-form");
const nameInput = document.getElementById("name-input");
const emailInput = document.getElementById("email-input");
const admissionInput = document.getElementById("admission-input");
const cartError = document.getElementById("cart-error");
const confirmation = document.getElementById("confirmation");
const confirmationText = document.getElementById("confirmation-text");

// ---------- Helpers ----------
function findProduct(id) {
  for (let i = 0; i < products.length; i++) {
    if (products[i].id === id) {
      return products[i];
    }
  }
  return null;
}

function showError(errorEl, inputEl, message) {
  errorEl.textContent = message;
  errorEl.classList.add("visible");
  if (inputEl) {
    inputEl.classList.add("invalid");
  }
}

function clearError(errorEl, inputEl) {
  errorEl.classList.remove("visible");
  if (inputEl) {
    inputEl.classList.remove("invalid");
  }
}

// ---------- FILTER ----------
// Reads the controls, rebuilds state.filtered, then re-renders BOTH views.
function applyFilters() {
  state.category = categorySelect.value;
  state.query = searchInput.value.trim().toLowerCase();

  const priceText = priceInput.value.trim();
  const priceNumber = Number(priceText);
  state.maxPrice = priceText !== "" && Number.isFinite(priceNumber) && priceNumber > 0 ? priceNumber : null;

  const results = [];
  for (const product of products) {
    const matchesCategory = state.category === "All" || product.category === state.category;
    const matchesQuery = state.query === "" || product.name.toLowerCase().includes(state.query);
    const matchesPrice = state.maxPrice === null || product.price <= state.maxPrice;
    if (matchesCategory && matchesQuery && matchesPrice) {
      results.push(product);
    }
  }

  state.filtered = results;
  state.slideIndex = 0; // new results -> start the gallery from the first one

  renderCatalog();
  renderGallery(false);
}

function renderCatalog() {
  productGrid.replaceChildren();

  const count = state.filtered.length;
  resultCount.textContent = count === 1 ? "1 item found" : count + " items found";

  if (count === 0) {
    const empty = document.createElement("p");
    empty.className = "empty-state";
    empty.textContent = "No products match your filters. Try a different category, search word or price.";
    productGrid.appendChild(empty);
    return;
  }

  state.filtered.forEach(function (product, index) {
    const card = document.createElement("article");
    card.className = "product-card";
    card.dataset.index = String(index);
    if (index === state.slideIndex) {
      card.classList.add("active");
    }

    const img = document.createElement("img");
    img.src = product.image;
    img.alt = product.alt;

    const title = document.createElement("h3");
    title.textContent = product.name;

    const meta = document.createElement("p");
    meta.className = "meta";
    meta.textContent = product.category + " · KES " + product.price;

    const addBtn = document.createElement("button");
    addBtn.type = "button";
    addBtn.textContent = "Add to cart";
    addBtn.dataset.productId = String(product.id);

    card.append(img, title, meta, addBtn);
    productGrid.appendChild(card);
  });
}

// ---------- GALLERY (reads state.filtered) ----------
function renderGallery(animate) {
  const count = state.filtered.length;

  if (count === 0) {
    gallery.classList.add("empty");
    galleryImage.removeAttribute("src");
    galleryImage.alt = "";
    galleryCaption.textContent = "No images to show for the current filters.";
    galleryCounter.textContent = "0 of 0";
    return;
  }

  gallery.classList.remove("empty");
  const product = state.filtered[state.slideIndex];

  function swap() {
    galleryImage.src = product.image;
    galleryImage.alt = product.alt;
    galleryImage.classList.remove("fading");
  }

  if (animate) {
    galleryImage.classList.add("fading");
    setTimeout(swap, 150);
  } else {
    swap();
  }

  galleryCaption.textContent = product.name + " – KES " + product.price;
  galleryCounter.textContent = (state.slideIndex + 1) + " of " + count;

  // keep the highlighted card in the grid in sync with the slide
  const cards = productGrid.querySelectorAll(".product-card");
  cards.forEach(function (card) {
    card.classList.toggle("active", Number(card.dataset.index) === state.slideIndex);
  });
}

function moveSlide(step) {
  const count = state.filtered.length;
  if (count === 0) {
    return;
  }
  // wraparound at both ends
  state.slideIndex = (state.slideIndex + step + count) % count;
  renderGallery(true);
}

// ---------- QUANTITY VALIDATION ----------
// Returns { valid, value, message }. Only valid rows are ever summed.
function validateQuantity(raw) {
  const text = String(raw).trim();

  if (text === "") {
    return { valid: false, value: 0, message: "Quantity is required – enter a whole number from 1 to " + MAX_QTY + "." };
  }
  if (!/^-?\d+(\.\d+)?$/.test(text)) {
    return { valid: false, value: 0, message: "Quantity must be a number – letters and symbols like \"" + text + "\" are not allowed." };
  }

  const number = Number(text);
  if (number < 0) {
    return { valid: false, value: 0, message: "Quantity cannot be negative – you entered " + number + "." };
  }
  if (number === 0) {
    return { valid: false, value: 0, message: "Quantity cannot be zero – remove the item or enter at least 1." };
  }
  if (!Number.isInteger(number)) {
    return { valid: false, value: 0, message: "Quantity must be a whole number – you entered " + number + "." };
  }
  if (number > MAX_QTY) {
    return { valid: false, value: 0, message: "Only " + MAX_QTY + " of each item can be reserved – you entered " + number + "." };
  }
  return { valid: true, value: number, message: "" };
}

// ---------- CART ----------
function addToCart(productId) {
  const existing = state.cart.find(function (row) { return row.productId === productId; });
  if (existing) {
    const check = validateQuantity(existing.qtyRaw);
    // only increment when the current quantity is valid; otherwise reset it to 1
    existing.qtyRaw = check.valid ? String(Math.min(check.value + 1, MAX_QTY)) : "1";
  } else {
    state.cart.push({ productId: productId, qtyRaw: "1" });
  }
  renderCart();
}

function removeFromCart(productId) {
  state.cart = state.cart.filter(function (row) { return row.productId !== productId; });
  renderCart();
}

function renderCart() {
  cartList.replaceChildren();
  cartEmpty.style.display = state.cart.length === 0 ? "block" : "none";

  state.cart.forEach(function (row) {
    const product = findProduct(row.productId);

    const li = document.createElement("li");
    li.className = "cart-row";
    li.dataset.productId = String(row.productId);

    const label = document.createElement("span");
    label.textContent = product.name + " (KES " + product.price + " each)";

    const qty = document.createElement("input");
    qty.type = "text";
    qty.inputMode = "numeric";
    qty.className = "qty";
    qty.value = row.qtyRaw;
    qty.setAttribute("aria-label", "Quantity for " + product.name);

    const removeBtn = document.createElement("button");
    removeBtn.type = "button";
    removeBtn.className = "remove-btn";
    removeBtn.textContent = "Remove";
    removeBtn.dataset.productId = String(row.productId);

    const lineTotal = document.createElement("span");
    lineTotal.className = "line-total";

    const rowError = document.createElement("p");
    rowError.className = "error row-error";
    rowError.setAttribute("role", "alert");

    li.append(label, qty, removeBtn, lineTotal, rowError);
    cartList.appendChild(li);

    updateRowDisplay(li, row);
  });

  updateTotal();
}

// Updates one row's validation message + line total (does not rebuild the DOM,
// so the user keeps their cursor while typing).
function updateRowDisplay(li, row) {
  const product = findProduct(row.productId);
  const check = validateQuantity(row.qtyRaw);
  const qtyInput = li.querySelector(".qty");
  const rowError = li.querySelector(".row-error");
  const lineTotal = li.querySelector(".line-total");

  if (check.valid) {
    li.classList.remove("invalid");
    clearError(rowError, qtyInput);
    lineTotal.textContent = "Line total: KES " + (product.price * check.value);
  } else {
    li.classList.add("invalid");
    showError(rowError, qtyInput, check.message);
    lineTotal.textContent = "Not included in total";
  }
}

// The total uses ONLY rows whose quantity passed validation.
function updateTotal() {
  let total = 0;
  let excluded = 0;

  for (const row of state.cart) {
    const check = validateQuantity(row.qtyRaw);
    if (check.valid) {
      total += findProduct(row.productId).price * check.value;
    } else {
      excluded++;
    }
  }

  cartTotal.textContent = String(total);

  if (excluded > 0) {
    cartNote.textContent = excluded === 1
      ? "1 item has an invalid quantity and is left out of the total. Fix the quantity shown in red."
      : excluded + " items have invalid quantities and are left out of the total. Fix the quantities shown in red.";
  } else {
    cartNote.textContent = "";
  }
}

// ---------- FORM VALIDATION ----------
function validateName(value) {
  const name = value.trim();
  if (name === "") {
    return "Full name is required.";
  }
  if (name.split(/\s+/).length < 2) {
    return "Please enter your full name – first and last name, separated by a space.";
  }
  return "";
}

function validateEmail(value) {
  const email = value.trim();
  if (email === "") {
    return "Email is required.";
  }
  if (!email.includes("@")) {
    return "Email must contain an @ symbol.";
  }
  const parts = email.split("@");
  if (parts.length > 2) {
    return "Email must contain only one @ symbol.";
  }
  if (parts[0] === "") {
    return "Email needs text before the @ symbol.";
  }
  if (parts[1] === "") {
    return "Email needs a domain after the @ symbol (e.g. gmail.com).";
  }
  if (!parts[1].includes(".") || parts[1].startsWith(".") || parts[1].endsWith(".")) {
    return "Email domain must contain a dot between its parts, like gmail.com.";
  }
  return "";
}

// Custom rule: admission number in the form CIT-227-101/2024
function validateAdmission(value) {
  const admission = value.trim().toUpperCase();
  if (admission === "") {
    return "Admission number is required.";
  }
  if (!/^[A-Z]{3}-\d{3}-\d{3}\/\d{4}$/.test(admission)) {
    return "Admission number must look like CIT-227-101/2024 (3 letters, 3 digits, 3 digits, a slash, then the 4-digit year).";
  }
  const year = Number(admission.split("/")[1]);
  const thisYear = new Date().getFullYear();
  if (year < 2015 || year > thisYear) {
    return "Admission year " + year + " is not valid – it must be between 2015 and " + thisYear + ".";
  }
  return "";
}

function validateCartForCheckout() {
  if (state.cart.length === 0) {
    return "Your cart is empty – add at least one item before reserving.";
  }
  for (const row of state.cart) {
    const check = validateQuantity(row.qtyRaw);
    if (!check.valid) {
      return findProduct(row.productId).name + ": " + check.message;
    }
  }
  return "";
}

function handleSubmit(event) {
  event.preventDefault();

  const nameMsg = validateName(nameInput.value);
  const emailMsg = validateEmail(emailInput.value);
  const admissionMsg = validateAdmission(admissionInput.value);
  const cartMsg = validateCartForCheckout();

  const fields = [
    [nameMsg, document.getElementById("name-error"), nameInput],
    [emailMsg, document.getElementById("email-error"), emailInput],
    [admissionMsg, document.getElementById("admission-error"), admissionInput],
    [cartMsg, cartError, null]
  ];

  let allValid = true;
  for (const [message, errorEl, inputEl] of fields) {
    if (message) {
      showError(errorEl, inputEl, message);
      allValid = false;
    } else {
      clearError(errorEl, inputEl);
    }
  }

  confirmation.classList.remove("success");

  if (!allValid) {
    return; // stop here – nothing reloads, nothing is included in a total
  }

  // Valid: build the summary from validated data only
  const total = cartTotal.textContent;
  const firstName = nameInput.value.trim().split(/\s+/)[0];
  confirmationText.textContent = "Thanks, " + firstName + "! Your items are reserved. Total to pay on pickup: KES " + total + ".";

  // restart the animation by removing, forcing reflow, then adding the class
  void confirmation.offsetWidth;
  confirmation.classList.add("success");

  const submitBtn = document.getElementById("submit-btn");
  submitBtn.classList.remove("pulse");
  void submitBtn.offsetWidth;
  submitBtn.classList.add("pulse");

  checkoutForm.reset();
  state.cart = [];
  renderCart();
}

// ---------- EVENT LISTENERS (no inline onclick anywhere) ----------
searchInput.addEventListener("input", applyFilters);
categorySelect.addEventListener("change", applyFilters);
priceInput.addEventListener("input", applyFilters);
filterForm.addEventListener("reset", function () {
  // reset fires before the controls clear, so wait a tick
  setTimeout(applyFilters, 0);
});
filterForm.addEventListener("submit", function (event) { event.preventDefault(); });

prevBtn.addEventListener("click", function () { moveSlide(-1); });
nextBtn.addEventListener("click", function () { moveSlide(1); });
document.addEventListener("keydown", function (event) {
  const tag = document.activeElement ? document.activeElement.tagName : "";
  if (tag === "INPUT" || tag === "SELECT" || tag === "TEXTAREA") {
    return;
  }
  if (event.key === "ArrowLeft") { moveSlide(-1); }
  if (event.key === "ArrowRight") { moveSlide(1); }
});

// one listener on the grid handles every "Add to cart" button, and card clicks
productGrid.addEventListener("click", function (event) {
  const addBtn = event.target.closest("button[data-product-id]");
  if (addBtn) {
    addToCart(Number(addBtn.dataset.productId));
    return;
  }
  const card = event.target.closest(".product-card");
  if (card) {
    state.slideIndex = Number(card.dataset.index);
    renderGallery(true);
  }
});

cartList.addEventListener("input", function (event) {
  if (!event.target.classList.contains("qty")) {
    return;
  }
  const li = event.target.closest(".cart-row");
  const row = state.cart.find(function (r) { return r.productId === Number(li.dataset.productId); });
  row.qtyRaw = event.target.value;
  updateRowDisplay(li, row);
  updateTotal();
});

cartList.addEventListener("click", function (event) {
  const removeBtn = event.target.closest(".remove-btn");
  if (removeBtn) {
    removeFromCart(Number(removeBtn.dataset.productId));
  }
});

// Clear field errors as soon as the user edits the field
[
  [nameInput, "name-error"],
  [emailInput, "email-error"],
  [admissionInput, "admission-error"]
].forEach(function (pair) {
  pair[0].addEventListener("input", function () {
    clearError(document.getElementById(pair[1]), pair[0]);
    confirmation.classList.remove("success");
  });
});

checkoutForm.addEventListener("submit", handleSubmit);

// ---------- Start ----------
applyFilters();
renderCart();
