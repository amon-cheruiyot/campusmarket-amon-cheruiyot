Full Name: Amon Cheruiyot
Admission Number: [YOUR ADMISSION NUMBER]
Live Site: [YOUR NETLIFY/VERCEL LINK, e.g. https://campusmarket-amoncheruiyot.netlify.app]

# CampusMarket

CCS 2314 – Web Based Programming II, Assignment 4 (Weeks 1–4 integration).

## Files
- `index.html` – catalog, gallery, cart and reservation form
- `about.html` – about page
- `styles.css` – layout, transitions and `@keyframes`
- `app.js` – all JavaScript (no inline scripts, no `onclick` attributes)
- `images/` – product illustrations (SVG)

## How the pieces work together
1. **Filter drives gallery.** `app.js` keeps one `products` array and one `state.filtered` list. `applyFilters()` rebuilds `state.filtered`, then `renderCatalog()` and `renderGallery()` both read from it. The gallery slides, counter and wraparound all use `state.filtered`.
2. **Validated totals.** Each cart quantity is stored as the raw text typed. `validateQuantity()` checks it (empty, non-numeric, negative, zero, decimal, above 20). `updateTotal()` sums only rows that pass; invalid rows are marked red, explained, and excluded.
3. **Animated success.** On a valid submit, `handleSubmit()` adds the `success` class to the confirmation panel, which runs the `confirm-pop` and `draw` keyframe animations. No `alert()`.
4. **Specific errors.** Each rule returns its own message (e.g. "Email must contain an @ symbol."). `.error` elements fade and slide via CSS transitions when the `visible` class is toggled.
5. **Alt text.** Every `<img>` has descriptive alt text (product alt text comes from the `products` array).

## Validation rules
- Required: name, email, admission number, quantity
- Format: email (@ and domain), admission number pattern `BSE-01-2024-1234`
- Custom: full name needs two words; admission year must be 2015 to the current year; quantity 1–20

## Deploying
Push to the private GitHub repo, import it in Netlify or Vercel (default settings, no build command), then paste the live link on the `Live Site:` line (line 3) of this README.
